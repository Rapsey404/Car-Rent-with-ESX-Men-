local ESX = exports['es_extended']:getSharedObject()

CreateThread(function()
    for _, rapsey_loc in pairs(Rapsey.Locations) do
        local rapsey_blip = AddBlipForCoord(rapsey_loc.coords)
        SetBlipSprite(rapsey_blip, 225)
        SetBlipDisplay(rapsey_blip, 4)
        SetBlipScale(rapsey_blip, 0.8)
        SetBlipColour(rapsey_blip, 3)
        SetBlipAsShortRange(rapsey_blip, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(rapsey_loc.label)
        EndTextCommandSetBlipName(rapsey_blip)
    end
end)

local function rapsey_marker_magic(coords)
    DrawMarker(Rapsey.Marker.type, coords.x, coords.y, coords.z + 0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Rapsey.Marker.scale.x, Rapsey.Marker.scale.y, Rapsey.Marker.scale.z, Rapsey.Marker.color.r, Rapsey.Marker.color.g, Rapsey.Marker.color.b, Rapsey.Marker.color.a, false, true, 2, false, nil, nil, false)
end

CreateThread(function()
    local rapsey_sleep = 1000
    local rapsey_player, rapsey_coords, rapsey_inrange, rapsey_inmarker, rapsey_nearest, rapsey_mindist = nil, nil, false, false, nil, math.huge
    local rapsey_marker_active = false
    local rapsey_help_shown = false
    local rapsey_last_marker = nil
    while true do
        rapsey_player = PlayerPedId()
        rapsey_coords = GetEntityCoords(rapsey_player)
        rapsey_inrange, rapsey_inmarker, rapsey_nearest, rapsey_mindist = false, false, nil, math.huge
        for _, rapsey_loc in pairs(Rapsey.Locations) do
            local coords = rapsey_loc.coords
            if coords and type(coords) == 'vector3' then
                local dist = #(rapsey_coords - coords)
                if dist < rapsey_mindist then rapsey_mindist = dist rapsey_nearest = rapsey_loc end
                if dist < 10.0 then
                    rapsey_inrange = true
                    if dist < 1.5 then rapsey_inmarker = true end
                end
            end
        end
        if rapsey_inrange and rapsey_nearest then
            if not rapsey_marker_active or rapsey_last_marker ~= rapsey_nearest then
                rapsey_marker_active = true
                rapsey_last_marker = rapsey_nearest
                CreateThread(function()
                    while rapsey_marker_active and #(GetEntityCoords(PlayerPedId()) - rapsey_nearest.coords) < 10.0 do
                        rapsey_marker_magic(rapsey_nearest.coords)
                        Wait(0)
                    end
                    rapsey_marker_active = false
                end)
            end
        else
            rapsey_marker_active = false
            rapsey_last_marker = nil
        end
        if not rapsey_inrange then
            rapsey_sleep = 1500
        else
            rapsey_sleep = rapsey_inmarker and 1 or 75
            if rapsey_inmarker and rapsey_nearest then
                if not rapsey_help_shown and not rapsey_menu_open then
                    ESX.ShowHelpNotification('Drücke ~INPUT_CONTEXT~ um ein Fahrzeug zu mieten')
                    rapsey_help_shown = true
                end
                if IsControlJustReleased(0, 38) then
                    if not rapsey_menu_open then
                        rapsey_menu_open = true
                        TriggerEvent('Rapsey:openRentalMenu', rapsey_nearest)
                        rapsey_menu_open = false
                        rapsey_help_shown = false
                    end
                end
            else
                rapsey_help_shown = false
            end
        end
        Wait(rapsey_sleep)
    end
end)

RegisterNetEvent('Rapsey:openRentalMenu', function(rapsey_loc)
    local rapsey_elements = {}
    for _, rapsey_vehicle in pairs(rapsey_loc.vehicles) do
        table.insert(rapsey_elements, {label = rapsey_vehicle.label .. ' - $' .. rapsey_vehicle.price, value = rapsey_vehicle.model, price = rapsey_vehicle.price})
    end
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'rental_menu', {
        title = Rapsey.ESXMenuTitle,
        align = 'top-left',
        elements = rapsey_elements
    }, function(data, menu)
        local rapsey_spawn = rapsey_loc.spawn or rapsey_loc.coords
        local rapsey_heading = rapsey_loc.spawnHeading or rapsey_loc.heading or 0.0
        TriggerServerEvent('Rapsey:rentVehicle', data.current.value, data.current.price, rapsey_spawn, rapsey_heading)
        menu.close()
    end, function(data, menu)
        menu.close()
    end)
end)

RegisterNetEvent('Rapsey:spawnRentedVehicle', function(rapsey_model, rapsey_coords, rapsey_heading)
    ESX.Game.SpawnVehicle(rapsey_model, rapsey_coords, rapsey_heading, function(rapsey_vehicle)
        TaskWarpPedIntoVehicle(PlayerPedId(), rapsey_vehicle, -1)
        ESX.ShowNotification('Viel Spaß mit deinem Fahrzeug!')
    end)
end)
