fx_version 'cerulean'
game 'gta5'

author 'Rapsey'

shared_script 'config.lua'
client_script 'client/main.lua'
server_script 'server/main.lua'

dependency 'es_extended'
